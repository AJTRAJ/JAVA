x = 5
print "Memory location of x:",id(x)

x = 6
print "Memory location of x:",id(x)

y = 5
print "Memory location of y:",id(y)
