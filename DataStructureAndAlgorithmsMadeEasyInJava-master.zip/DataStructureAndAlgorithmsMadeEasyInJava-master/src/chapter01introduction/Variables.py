# your code goes here#Assign x to a Integer
x = 5
print "The value of x is:", x
print "The type of x is:", type(x)
print "The memory location of x is:", id(x)

#Assign x to a Float
x = 6.5
print "The value of x is:", x
print "The type of x is:", type(x)
print "The memory location of x is:", id(x)

#Assign x to a String
x = "CodingDucks.org"
print "The value of x is:", x
print "The type of x is:", type(x)
print "The memory location of x is:", id(x) 
