package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.RelationShipType;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Relationship
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2020-05-19T06:38:09.320Z[GMT]")
public class Relationship   {
  @JsonProperty("reltypeID")
  private Integer reltypeID = null;

  @JsonProperty("reltype")
  private RelationShipType reltype = null;

  @JsonProperty("sourceItemId")
  private Integer sourceItemId = null;

  @JsonProperty("targetItemId")
  private Integer targetItemId = null;

  @JsonProperty("description")
  private String description = null;

  public Relationship reltypeID(Integer reltypeID) {
    this.reltypeID = reltypeID;
    return this;
  }

  /**
   * Get reltypeID
   * @return reltypeID
  **/
  @ApiModelProperty(example = "87", value = "")
  
    public Integer getReltypeID() {
    return reltypeID;
  }

  public void setReltypeID(Integer reltypeID) {
    this.reltypeID = reltypeID;
  }

  public Relationship reltype(RelationShipType reltype) {
    this.reltype = reltype;
    return this;
  }

  /**
   * Get reltype
   * @return reltype
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public RelationShipType getReltype() {
    return reltype;
  }

  public void setReltype(RelationShipType reltype) {
    this.reltype = reltype;
  }

  public Relationship sourceItemId(Integer sourceItemId) {
    this.sourceItemId = sourceItemId;
    return this;
  }

  /**
   * Get sourceItemId
   * @return sourceItemId
  **/
  @ApiModelProperty(example = "123", value = "")
  
    public Integer getSourceItemId() {
    return sourceItemId;
  }

  public void setSourceItemId(Integer sourceItemId) {
    this.sourceItemId = sourceItemId;
  }

  public Relationship targetItemId(Integer targetItemId) {
    this.targetItemId = targetItemId;
    return this;
  }

  /**
   * Get targetItemId
   * @return targetItemId
  **/
  @ApiModelProperty(example = "234", value = "")
  
    public Integer getTargetItemId() {
    return targetItemId;
  }

  public void setTargetItemId(Integer targetItemId) {
    this.targetItemId = targetItemId;
  }

  public Relationship description(String description) {
    this.description = description;
    return this;
  }

  /**
   * Get description
   * @return description
  **/
  @ApiModelProperty(example = "To Push the relationship between source and target", value = "")
  
    public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Relationship relationship = (Relationship) o;
    return Objects.equals(this.reltypeID, relationship.reltypeID) &&
        Objects.equals(this.reltype, relationship.reltype) &&
        Objects.equals(this.sourceItemId, relationship.sourceItemId) &&
        Objects.equals(this.targetItemId, relationship.targetItemId) &&
        Objects.equals(this.description, relationship.description);
  }

  @Override
  public int hashCode() {
    return Objects.hash(reltypeID, reltype, sourceItemId, targetItemId, description);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Relationship {\n");
    
    sb.append("    reltypeID: ").append(toIndentedString(reltypeID)).append("\n");
    sb.append("    reltype: ").append(toIndentedString(reltype)).append("\n");
    sb.append("    sourceItemId: ").append(toIndentedString(sourceItemId)).append("\n");
    sb.append("    targetItemId: ").append(toIndentedString(targetItemId)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
