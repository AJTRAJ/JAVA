package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.AdditionalProperties;
import io.swagger.model.Metadata;
import io.swagger.model.MetadataType;
import io.swagger.model.Properties;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Metadata
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2020-05-18T09:26:58.244Z[GMT]")
public class Metadata   {
  @JsonProperty("id")
  private Long id = null;

  @JsonProperty("parentid")
  private Long parentid = null;

  @JsonProperty("name")
  private String name = null;

  @JsonProperty("metadatatype")
  private MetadataType metadatatype = null;

  @JsonProperty("additionalproperties")
  private AdditionalProperties additionalproperties = null;

  @JsonProperty("properties")
  private Properties properties = null;

  @JsonProperty("children")
  @Valid
  private List<Metadata> children = null;

  public Metadata id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
  **/
  @ApiModelProperty(example = "123", required = true, value = "")
      @NotNull

    public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Metadata parentid(Long parentid) {
    this.parentid = parentid;
    return this;
  }

  /**
   * Get parentid
   * @return parentid
  **/
  @ApiModelProperty(example = "345", required = true, value = "")
      @NotNull

    public Long getParentid() {
    return parentid;
  }

  public void setParentid(Long parentid) {
    this.parentid = parentid;
  }

  public Metadata name(String name) {
    this.name = name;
    return this;
  }

  /**
   * Get name
   * @return name
  **/
  @ApiModelProperty(example = "Source", required = true, value = "")
      @NotNull

    public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Metadata metadatatype(MetadataType metadatatype) {
    this.metadatatype = metadatatype;
    return this;
  }

  /**
   * Get metadatatype
   * @return metadatatype
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public MetadataType getMetadatatype() {
    return metadatatype;
  }

  public void setMetadatatype(MetadataType metadatatype) {
    this.metadatatype = metadatatype;
  }

  public Metadata additionalproperties(AdditionalProperties additionalproperties) {
    this.additionalproperties = additionalproperties;
    return this;
  }

  /**
   * Get additionalproperties
   * @return additionalproperties
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public AdditionalProperties getAdditionalproperties() {
    return additionalproperties;
  }

  public void setAdditionalproperties(AdditionalProperties additionalproperties) {
    this.additionalproperties = additionalproperties;
  }

  public Metadata properties(Properties properties) {
    this.properties = properties;
    return this;
  }

  /**
   * Get properties
   * @return properties
  **/
  @ApiModelProperty(value = "")
  
    @Valid
    public Properties getProperties() {
    return properties;
  }

  public void setProperties(Properties properties) {
    this.properties = properties;
  }

  public Metadata children(List<Metadata> children) {
    this.children = children;
    return this;
  }

  public Metadata addChildrenItem(Metadata childrenItem) {
    if (this.children == null) {
      this.children = new ArrayList<Metadata>();
    }
    this.children.add(childrenItem);
    return this;
  }

  /**
   * Get children
   * @return children
  **/
  @ApiModelProperty(value = "")
      @Valid
    public List<Metadata> getChildren() {
    return children;
  }

  public void setChildren(List<Metadata> children) {
    this.children = children;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Metadata metadata = (Metadata) o;
    return Objects.equals(this.id, metadata.id) &&
        Objects.equals(this.parentid, metadata.parentid) &&
        Objects.equals(this.name, metadata.name) &&
        Objects.equals(this.metadatatype, metadata.metadatatype) &&
        Objects.equals(this.additionalproperties, metadata.additionalproperties) &&
        Objects.equals(this.properties, metadata.properties) &&
        Objects.equals(this.children, metadata.children);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, parentid, name, metadatatype, additionalproperties, properties, children);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Metadata {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    parentid: ").append(toIndentedString(parentid)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    metadatatype: ").append(toIndentedString(metadatatype)).append("\n");
    sb.append("    additionalproperties: ").append(toIndentedString(additionalproperties)).append("\n");
    sb.append("    properties: ").append(toIndentedString(properties)).append("\n");
    sb.append("    children: ").append(toIndentedString(children)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
