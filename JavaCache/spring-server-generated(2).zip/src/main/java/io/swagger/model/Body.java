package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Metadata;
import io.swagger.model.Relationship;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Body
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2020-05-18T09:26:58.244Z[GMT]")
public class Body   {
  @JsonProperty("metadata")
  @Valid
  private List<Metadata> metadata = null;

  @JsonProperty("relationship")
  @Valid
  private List<Relationship> relationship = null;

  public Body metadata(List<Metadata> metadata) {
    this.metadata = metadata;
    return this;
  }

  public Body addMetadataItem(Metadata metadataItem) {
    if (this.metadata == null) {
      this.metadata = new ArrayList<Metadata>();
    }
    this.metadata.add(metadataItem);
    return this;
  }

  /**
   * Get metadata
   * @return metadata
  **/
  @ApiModelProperty(value = "")
      @Valid
    public List<Metadata> getMetadata() {
    return metadata;
  }

  public void setMetadata(List<Metadata> metadata) {
    this.metadata = metadata;
  }

  public Body relationship(List<Relationship> relationship) {
    this.relationship = relationship;
    return this;
  }

  public Body addRelationshipItem(Relationship relationshipItem) {
    if (this.relationship == null) {
      this.relationship = new ArrayList<Relationship>();
    }
    this.relationship.add(relationshipItem);
    return this;
  }

  /**
   * Get relationship
   * @return relationship
  **/
  @ApiModelProperty(value = "")
      @Valid
    public List<Relationship> getRelationship() {
    return relationship;
  }

  public void setRelationship(List<Relationship> relationship) {
    this.relationship = relationship;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Body body = (Body) o;
    return Objects.equals(this.metadata, body.metadata) &&
        Objects.equals(this.relationship, body.relationship);
  }

  @Override
  public int hashCode() {
    return Objects.hash(metadata, relationship);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Body {\n");
    
    sb.append("    metadata: ").append(toIndentedString(metadata)).append("\n");
    sb.append("    relationship: ").append(toIndentedString(relationship)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
