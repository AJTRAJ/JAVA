package io.swagger.model;

import java.util.Objects;
import io.swagger.annotations.ApiModel;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * metadata Item type to identify the nodes
 */
public enum MetadataType {
  DATABASE("database"),
    SCHEMA("schema"),
    SERVER("server"),
    TABLE("table"),
    COLUMN("column"),
    DATALAKE("datalake"),
    KAFKA("kafka"),
    TOPIC("topic"),
    PARTITION("partition"),
    FILESYSTEM("filesystem"),
    BLOBSTORAGE("blobstorage"),
    MESSAGE("message"),
    INDEX("index"),
    FOREIGNKEY("foreignKey"),
    CONNECTORS("connectors"),
    VERSION("version"),
    PIPELINE("pipeline");

  private String value;

  MetadataType(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static MetadataType fromValue(String text) {
    for (MetadataType b : MetadataType.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}
