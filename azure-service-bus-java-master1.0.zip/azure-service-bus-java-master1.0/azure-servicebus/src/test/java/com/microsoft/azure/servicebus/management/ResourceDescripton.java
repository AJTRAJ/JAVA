package com.microsoft.azure.servicebus.management;

public abstract class ResourceDescripton {
    abstract String getAtomXml();
    public abstract String getPath();
}
