package com.microsoft.azure.servicebus.management;

public class ManagementException extends Exception{
    
    private static final long serialVersionUID = -2884923885075130724L;

    public ManagementException() {
        super();
        // TODO Auto-generated constructor stub
    }

    public ManagementException(String message, Throwable cause) {
        super(message, cause);
        // TODO Auto-generated constructor stub
    }

    public ManagementException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

    public ManagementException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }
     
}
